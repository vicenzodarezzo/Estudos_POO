public class Main {

    public static void main(String[] args) {
        Bozo jogo = new Bozo();
        jogo.main();
        jogo.close();
    }

}
